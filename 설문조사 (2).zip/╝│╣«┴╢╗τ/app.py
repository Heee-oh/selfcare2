from flask import Flask, jsonify, request
from flask_cors import CORS
from flask import render_template
app = Flask(__name__)
CORS(app)
questions = [
    {"question_id": 1, "question_text": "출근하는 생각만 해도 짜증과 함께 가슴이 답답함을 느낀다."},
    {"question_id": 2, "question_text": "직장에서 칭찬을 들어도 썩 즐거운 기분이 들지 않는다."},
    {"question_id": 3, "question_text": "직장생활 외에 개인적인 생활이나 시간이 거의 없다."},
    {"question_id": 4, "question_text": "기력이 없고 쇠약해진 느낌이 든다."},
    {"question_id": 5, "question_text": "일하는 것에 심적 부담과 자신의 한계를 느낀다."},
    {"question_id": 6, "question_text": "충분한 시간의 잠을 자도 계속 피곤함을 느낀다."},
    {"question_id": 7, "question_text": "이전에는 그냥 넘어가던 일에도 화를 참을 수 없다."},
    {"question_id": 8, "question_text": "혼자 지내는 시간이 많아졌다."},
    {"question_id": 9, "question_text": "현재 업무에 대한 관심이 크게 줄었다."},
    {"question_id": 10, "question_text": "주변 사람에게 실망하는 일이 잦다."},
    {"question_id": 11, "question_text": "주변에서 고민이 많거나 아파보인다는 말을 자주 듣는다."},
    {"question_id": 12, "question_text": "성욕이 감소했다."},
    {"question_id": 13, "question_text": "나의 직무 기여도에 대해 스스로 매우 낮다는 생각을 한다."},
    {"question_id": 14, "question_text": "만성피로, 감기나 두통, 요통, 소화불량이 늘었다."},
    {"question_id": 15, "question_text": "주변 사람과 대화를 나누는 것이 힘들게 느껴진다."},
]
saved_score = 0
@app.route('/')
def index():
    return render_template('survey.html')

#------------------------------------------------

    
# JSON 데이터를 제공하는 엔드포인트
@app.route('/get_question/<int:question_id>', methods=['GET'])
def get_question(question_id):
    for question in questions:
        if question['question_id'] == question_id:
            return jsonify(question)
    return jsonify({'message': 'Question not found'})

@app.route('/save_result', methods=['POST'])
def save_result():
    global saved_score

    data = request.json
    saved_score = data.get('totalScore', 0)

    return jsonify({'message': 'Result saved successfully!'})

@app.route('/get_result', methods=['GET'])
def get_result():
    global saved_score

    return jsonify({'totalScore': saved_score})

if __name__ == '__main__':
    app.run(debug=True)
