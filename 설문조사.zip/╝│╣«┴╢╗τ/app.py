from flask import Flask, jsonify, request
from flask_cors import CORS
from flask import render_template
app = Flask(__name__)
CORS(app)
# 가상의 설문지 데이터
questions = [
    {"question_id": 1, "question_text": "출근하는 생각만 해도 짜증과 함께 가슴이 답답함을 느낀다."},
    {"question_id": 2, "question_text": "직장에서 칭찬을 들어도 썩 즐거운 기분이 들지 않는다."},
    {"question_id": 3, "question_text": "직장생활 외에 개인적인 생활이나 시간이 거의 없다."},
    {"question_id": 4, "question_text": "기력이 없고 쇠약해진 느낌이 든다."},
    {"question_id": 5, "question_text": "일하는 것에 심적 부담과 자신의 한계를 느낀다."},
    {"question_id": 6, "question_text": "충분한 시간의 잠을 자도 계속 피곤함을 느낀다."},
    {"question_id": 7, "question_text": "이전에는 그냥 넘어가던 일에도 화를 참을 수 없다."},
    {"question_id": 8, "question_text": "혼자 지내는 시간이 많아졌다."},
    {"question_id": 9, "question_text": "현재 업무에 대한 관심이 크게 줄었다."},
    {"question_id": 10, "question_text": "주변 사람에게 실망하는 일이 잦다."},
    {"question_id": 11, "question_text": "주변에서 고민이 많거나 아파보인다는 말을 자주 듣는다."},
    {"question_id": 12, "question_text": "성욕이 감소했다."},
    {"question_id": 13, "question_text": "나의 직무 기여도에 대해 스스로 매우 낮다는 생각을 한다."},
    {"question_id": 14, "question_text": "만성피로, 감기나 두통, 요통, 소화불량이 늘었다."},
    {"question_id": 15, "question_text": "주변 사람과 대화를 나누는 것이 힘들게 느껴진다."},
]
@app.route('/')
def index():
    return render_template('survey.html')

@app.route('/result')
def result():
    return render_template('result.html')

@app.route('/get_result', methods=['GET'])
def get_result():
    # 여기서 결과를 계산하고 반환
    score = 32  # 예시로 32를 사용
    result_text = ""

    # 점수에 따른 결과 텍스트 설정
    if score < 10:
        result_text = "점수가 10보다 작습니다."
    elif score >= 10 and score < 20:
        result_text = "점수가 10보다 크거나 같고 20보다 작습니다."
    else:
        result_text = "점수가 20 이상입니다."

    # 결과를 JSON 형태로 반환
    return jsonify({'result': result_text})

@app.route('/receive_data', methods=['POST'])
def receive_data():
    data = request.get_json()
    selected_score = int(data['score'])  # JSON에서 점수 추출
    # 점수를 기준으로 문구 결정하기
    result_text = get_result_text(selected_score)
    return jsonify({'result_text': result_text})

# JSON 데이터를 제공하는 엔드포인트
@app.route('/get_question/<int:question_id>', methods=['GET'])
def get_question(question_id):
    for question in questions:
        if question['question_id'] == question_id:
            return jsonify(question)
    return jsonify({'message': 'Question not found'})

@app.route('/submit_data', methods=['POST'])
def submit_data():
    data = request.json  # 클라이언트가 보낸 JSON 데이터를 가져옵니다.
    # 여기서 데이터를 처리하고 필요한 작업을 수행합니다.
    print('Received data:', data)
    # 처리가 끝나면 클라이언트에게 응답을 보냅니다.
    return jsonify({'message': 'Data received successfully!'})

if __name__ == '__main__':
    app.run(debug=True)